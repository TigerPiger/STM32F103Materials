# DLIB (IAR) porting for RT-Thread

Please define RT_USING_LIBC and compile RT-Thread with IAR compiler.



## More Information

http://www.iarsys.co.jp/download/LMS2/arm/7502/ewarm7502doc/arm/doc/EWARM_DevelopmentGuide.ENU.pdf    P.130